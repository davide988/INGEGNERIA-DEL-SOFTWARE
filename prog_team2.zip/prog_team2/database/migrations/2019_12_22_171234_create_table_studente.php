<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

class CreateTableStudente extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        Schema::create('studente', function (Blueprint $table) {
            $table->integer('matricola')->primary();
            $table->string('Email_S');
            $table->string('Password_S');
             $table->string('Nome_S');
             $table->string('Cognome_S');
             $table->string('Codice_C');
            
            $table->foreign('Codice_C')->references('Codice_C')->on('CDL');
            
            $table->timestamps();
        });
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        Schema::dropIfExists('studente');
    }
}
