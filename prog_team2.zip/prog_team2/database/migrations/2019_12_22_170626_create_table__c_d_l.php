<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

class CreateTableCDL extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        Schema::create('CDL', function (Blueprint $table) {
            $table->string('Codice_C')->primary();
            $table->string('Descrizione_C');
            $table->string('Nome_C');
            $table->string('Codice_D');
            
            $table->foreign('Codice_D')->references('Codice_D')->on('dipartimento');
           
            $table->timestamps();
        });
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        Schema::dropIfExists('CDL');
    }
}
