<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

class CreateTablePOI extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        Schema::create('POI', function (Blueprint $table) {
            $table->string('Codice_P')->primary();
            $table->string('Nome_P');
            $table->string('Tipologia');
            $table->string('Descrizione');
            $table->string('coordinate');
            $table->string('Username');
            
            $table->timestamps();
        });
        
        

    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        Schema::dropIfExists('POI');
    }
}
