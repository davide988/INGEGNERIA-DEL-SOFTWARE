<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

class CreateTableAssociato extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        Schema::create('poi_cdl', function (Blueprint $table) {
            $table->increments('id');
            $table->integer('poi_id');
            $table->integer('cdl_id');
            
            $table->foreign('poi_id')->references('id_p')->on('poi');
            $table->foreign('cdl_id')->references('id_c')->on('cdl');
        });
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        Schema::dropIfExists('associate');
    }
}
