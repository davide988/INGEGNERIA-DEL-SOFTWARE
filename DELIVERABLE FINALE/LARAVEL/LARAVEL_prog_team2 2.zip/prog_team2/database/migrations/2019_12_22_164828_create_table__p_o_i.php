<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

class CreateTablePOI extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        Schema::create('poi', function (Blueprint $table) {
            $table->integer('id_p')->primary();
            $table->string('name_p');
            $table->string('type');
            $table->string('description');
            $table->string('image');
            $table->string('area_p');
            $table->string('address');
            $table->string('position');
            $table->string('admin_id');
            
            $table->timestamps();
        });
        
        

    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        Schema::dropIfExists('poi');
    }
}
