<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

class CreateTableCDL extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        Schema::create('cdl', function (Blueprint $table) {
            $table->integer('id_c')->primary();
            $table->string('description_c');
            $table->string('name_c');
            $table->string('area_c');
            $table->integer('department_id');
            
            $table->foreign('department_id')->references('id_d')->on('departments');
           
            $table->timestamps();
        });
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        Schema::dropIfExists('CDL');
    }
}
