<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

class CreateTablePresiede extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        Schema::create('professors_cdl', function (Blueprint $table) {
            $table->increments('id');
            
            $table->string('professors_id');
            $table->integer('cdl_id');
            
            $table->foreign('cdl_id')->references('id_c')->on('cdl');
            $table->foreign('professors_id')->references('email_p')->on('professors');
            
        });
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        Schema::dropIfExists('professors_cdl');
    }
}
