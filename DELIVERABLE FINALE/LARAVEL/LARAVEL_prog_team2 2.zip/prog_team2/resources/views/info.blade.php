<!DOCTYPE html>

<html lang="{{ str_replace('_', '-', app()->getLocale()) }}">
    <head>
   

        <title>PORTAMI A DESTINAZIONE</title>
        <link rel="stylesheet" href="css/style.css">
        <link rel="stylesheet" href="css/form-login.css">
        <link rel="stylesheet" href="https://www.w3schools.com/w3css/4/w3.css">
        <!-- Styles -->
       <style>
        </style>
    
</head>
    
<body>

    <div id="header">
        <div id="logo">
          <img  src="images/prova.png">
        </div>
        <div id="title">
        <h1>Portami a destinazione</h1> 
        </div>

    </div>
   



  
 
<div  class="w3-container">
     
  
  <div class="w3-bar w3-light-grey w3-border w3-padding">
    <a href="http://127.0.0.1:8000/" class="w3-bar-item w3-button w3-mobile">Torna alla mappa</a>
    
   <!-- <a href="#" class="w3-bar-item w3-button w3-mobile">Link 2</a> -->
   @if (Auth::check())
    
    
    <a class="w3-bar-item w3-button w3-mobile log-button" style="margin-left:80%;" href="{{ route('logout') }}"
                                       onclick="event.preventDefault();
                                                     document.getElementById('logout-form').submit();">
                                        Ciao {{Auth::User()->name}}, LOGOUT
                                    </a> 
                                    <form id="logout-form" action="{{ route('logout') }}" method="POST" style="display: none;">
                                        @csrf
                                    </form>
   @else
    <a href="http://127.0.0.1:8000/login"  id="login-button" class="w3-bar-item w3-button w3-mobile log-button">Login</a>

   @endif
    
    </div>

</div>


<!-- --------------- -->

        <!-- ------------->
        <br>
        
        <div id="dati">
        @foreach ($student as $st)

    
    
    
   


<table class="dati">
                    <tr>
                        <td style="padding-bottom:30px;"><h10>nome:</h10></td ><td id="nome_area" style="padding-bottom:30px;"><h21> {{$st['name']}}</h21></td>
                    </tr>
                    <tr>
                        <td style="padding-bottom:30px;"><h10>cognome:</h10></td><td id="cognome_area" style="padding-bottom:30px;"><h21>{{$st['surname_s']}}</h21></td>
                    <tr>
                        <td style="padding-bottom:30px; width:200px;"><h10>e-mail:</h10></td><td id="email_area" style="padding-bottom:30px;"><h22>{{$st['email']}}</h22></td>
                    </tr>
<tr>
                        <td><h10>matricola:</h10></td><td id="numero_area"><h21>{{$st['freshman']}}</h21></td>
                    </tr>
<tr>
                        <td><h10>Corso di laurea':</h10></td><td id="citta_area"><h21>{{$st['description_c']}}</h21></td>
                    </tr>
<tr>
                        <td><h10>dipartimento:</h10></td><td id="indirizzo_area"><h21> {{$st['name_d']}}</h21></td>
                    </tr>
                    <tr>
                        <td><h10>password:</h10></td><td><h21>****************</h21></td><td><input class="tasto_modifica"value="Modifica"  type="button" name="isbn" onclick="location.href='#'"></td>
                    </tr>
                    
                
                    
                </table>
 </div>


    
 @endforeach





   

</body>
</html>

