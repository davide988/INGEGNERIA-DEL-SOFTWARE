<?php

/*
|--------------------------------------------------------------------------
| Web Routes
|--------------------------------------------------------------------------
|
| Here is where you can register web routes for your application. These
| routes are loaded by the RouteServiceProvider within a group which
| contains the "web" middleware group. Now create something great!
|
*/

Route::get('/', function () {
    return view('welcome');
});

Route::get('/login', function () {
    return view('login');
});

Route::get('/info', function () {
    return view('info');
});

route::get('/classroom', 'POIController@indexclassroom');
Route::get('/food_drink','POIController@indexfood_drink');
    Route::get('/office','POIController@indexoffice');
    Route::get('/secretariat','POIController@indexsecretariat');
    Route::get('/bus_stop','POIController@indexbus_stop');
    Route::get('/info_point','POIController@indexinfo_point');
    Route::get('/library','POIController@indexlibrary');
    Route::get('/toilet','POIController@indextoilet');
    
route::get('/', 'POIController@index');
route::get('/search', 'POIController@showsearch');
route::get('/info','StudentController@show')->name('info');
route::get('/filter','PoiController@showpoi')->name('filter');




Auth::routes();

Route::get('/home', 'HomeController@index')->name('home');
