<?php

use Illuminate\Http\Request;
use App\Http\resources\Poi;
use App\Http\resources\Cdl;





/*
|--------------------------------------------------------------------------
| API Routes
|--------------------------------------------------------------------------
|
| Here is where you can register API routes for your application. These
| routes are loaded by the RouteServiceProvider within a group which
| is assigned the "api" middleware group. Enjoy building your API!
|
*/

Route::middleware('auth:api')->get('/user', function (Request $request) {
    return $request->user();
});

//Route::resource('/Poi','POIController');
//Route::resource('/Cdl','CDLController');
//Route::resource('/association','AssociatoController');

/*

Route::prefix('Poi')->group(function() {
    Route::get('/','Poicontroller@index');
    
});


*/

Route::prefix('poi')->group(function() {
    Route::get('/','POIController@index');

    Route::get('/classroom','POIController@indexclassroom');
    Route::get('/food_drink','POIController@indexfood_drink');
    Route::get('/office','POIController@indexoffice');
    Route::get('/secretariat','POIController@indexsecretariat');
    Route::get('/bus_stop','POIController@indexbus_stop');
    Route::get('/info_point','POIController@indexinfo_point');
    Route::get('/library','POIController@indexlibrary');
    Route::get('/toilet','POIController@indextoilet');
    
    
    Route::get('/search/{searchText}','POIController@showsearch');
    Route::get('/{id_p}','POIController@show');
    Route::get('/dip/{dip}','POIController@show1');
    Route::get('/cdl/{id_p}','POIController@showpoi');
    Route::patch('/{id_p}','POIController@update');
    Route::delete('/{id_p}','POIController@destroy');
    Route::post('/','POIcontroller@store');
   // Route::delete('/{user}','UsersController@destroy')->middleware('auth');
   // Route::patch('/{user}','UsersController@update')->middleware('auth');
});


Route::prefix('cdl')->group(function() {
    Route::get('/','CDLController@index');
    Route::get('/{id_c}','CDLController@show');
    Route::patch('/{id_c}','CDLController@update');
    Route::delete('/{id_c}','CDLController@destroy');
    Route::post('/','CDLController@store');
});


Route::prefix('department')->group(function() {
    Route::get('/','DepartmentController@index');
    Route::get('/{id_d}','DepartmentController@show');
    Route::patch('/{id_d}','DepartmentController@update');
    Route::delete('/{id_d}','DepartmentController@destroy');
    Route::post('/','DepartmentController@store');
});

Route::prefix('professor')->group(function() {
    Route::get('/','ProfessorController@index');
    Route::get('/{email_p}','ProfessorController@show');
    Route::patch('/{email_p}','ProfessorController@update');
    Route::delete('/{email_p}','ProfessorController@destroy');
    Route::post('/','ProfessorController@store');
});

Route::prefix('student')->group(function() {
    Route::get('/','StudentController@index');
    Route::get('/info/{freshman}','StudentController@show');
    Route::get('/cdl/{freshman}','StudentController@showcdl');

    Route::patch('/{freshman}','StudentController@update');
    Route::delete('/{freshman}','StudentController@destroy');
    Route::post('/','StudentController@store');
});

