<!DOCTYPE html>

<html lang="<?php echo e(str_replace('_', '-', app()->getLocale())); ?>">
    <head>
   

        <title>PORTAMI A DESTINAZIONE</title>
        <link rel="stylesheet" href="css/style.css">
        <link rel="stylesheet" href="css/form-login.css">
        <link rel="stylesheet" href="https://www.w3schools.com/w3css/4/w3.css">
        <!-- Styles -->
       <style>
        </style>
    
</head>
    
<body>

    <div id="header">
        <div id="logo">
          <img  src="images/prova.png">
        </div>
        <div id="title">
        <h1>PORTAMI A DESTINAZIONE</h1> 
        </div>

    </div>
   

    <?php echo e($student['name_p']); ?>




  
 
<div  class="w3-container">
     
  
  <div class="w3-bar w3-light-grey w3-border w3-padding">
    <a href="http://127.0.0.1:8000/" class="w3-bar-item w3-button w3-mobile">Home</a>
    
   <!-- <a href="#" class="w3-bar-item w3-button w3-mobile">Link 2</a> -->
   
    
    </div>

</div>


<!-- --------------- -->

        <!-- ------------->
        <br>
        
    


    
       





   

</body>
</html>

<?php /**PATH /Applications/MAMP_2019-12-19_15-33-51/htdocs/prog_team2/resources/views//info.blade.php ENDPATH**/ ?>