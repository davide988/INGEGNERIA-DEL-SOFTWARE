<!DOCTYPE html>

<html lang="<?php echo e(str_replace('_', '-', app()->getLocale())); ?>">
    <head>
   

        <title>PORTAMI A DESTINAZIONE</title>
        <link rel="stylesheet" href="css/style.css">
        <link rel="stylesheet" href="css/form-login.css">
        <link rel="stylesheet" href="https://www.w3schools.com/w3css/4/w3.css">
        <!-- Styles -->
       <style>
        </style>
    
</head>
    
<body>

    <div id="header">
        <div id="logo">
          <img  src="images/prova.png">
        </div>
        <div id="title">
        <h1>PORTAMI A DESTINAZIONE</h1> 
        </div>

    </div>
  
 
<div  class="w3-container">
     
  
  <div class="w3-bar w3-light-grey w3-border w3-padding">
    <a href="http://127.0.0.1:8000/" class="w3-bar-item w3-button w3-mobile">Home</a>
    
   <!-- <a href="#" class="w3-bar-item w3-button w3-mobile">Link 2</a> -->
   
    
    </div>

</div>

<!-- --------------- -->
<div class="wrap-login100 p-l-55 p-r-55 p-t-65 p-b-50">
				<form class="login100-form validate-form">
					<span class="login100-form-title p-b-33">
						Account Login
					</span>

					<div class="wrap-input100 validate-input" data-validate = "Valid email is required: ex@abc.xyz">
						<input class="input100" type="text" name="email" placeholder="Email">
						<span class="focus-input100-1"></span>
						<span class="focus-input100-2"></span>
					</div>

					<div class="wrap-input100 rs1 validate-input" data-validate="Password is required">
						<input class="input100" type="password" name="pass" placeholder="Password">
						<span class="focus-input100-1"></span>
						<span class="focus-input100-2"></span>
					</div>

					<div class="container-login100-form-btn m-t-20">
						<button class="login100-form-btn">
							Login
						</button>
					</div>

					
					

					
				</form>
			</div>
        <!-- ------------->
        <br>
        
    


    
       





   

</body>
</html>

<?php /**PATH /Applications/MAMP_2019-12-19_15-33-51/htdocs/prog_team2/resources/views//profilo.blade.php ENDPATH**/ ?>