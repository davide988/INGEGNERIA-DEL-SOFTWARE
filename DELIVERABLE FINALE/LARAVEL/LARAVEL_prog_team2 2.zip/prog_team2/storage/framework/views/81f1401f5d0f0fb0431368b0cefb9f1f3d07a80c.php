<!DOCTYPE html>

<html lang="<?php echo e(str_replace('_', '-', app()->getLocale())); ?>">
    <head>
   

        <title>PORTAMI A DESTINAZIONE</title>
        <link rel="stylesheet" href="css/style.css">
        <link rel="stylesheet" href="https://www.w3schools.com/w3css/4/w3.css">
        <!-- Styles -->
       <style>
/* Dropdown Button */

        </style>
    
</head>
    
<body>

    <div id="header">
        <div id="logo">
          <img  src="images/prova.png">
        </div>
        <div id="title">
        <h1>PORTAMI A DESTINAZIONE</h1> 
       
        </div>

    </div>
  
 
<div  class="w3-container">
     
  
  <div class="w3-bar w3-light-grey w3-border w3-padding">
    <a href="http://127.0.0.1:8000/" class="w3-bar-item w3-button w3-mobile">Home</a>
   

   

   <form  class="form-ricerca" action="http://127.0.0.1:8000/search" method="Get">
   <input name="searchText" type="text" class="w3-bar-item w3-input w3-white w3-mobile" placeholder="Cerca...">
    <button class="w3-bar-item w3-button w3-mobile search_button">Vai</button>
</form>

<?php if(Auth::check()): ?>
    
    <a href="http://127.0.0.1:8000/info?freshman=<?php echo e(Auth::User()->freshman); ?>"  id="profilo" class="w3-bar-item w3-button w3-mobile"><img style="height:25px;" src="images/profilo.png"> </a> 
    <a class="w3-bar-item w3-button w3-mobile log-button" href="<?php echo e(route('logout')); ?>"
                                       onclick="event.preventDefault();
                                                     document.getElementById('logout-form').submit();">
                                        Ciao <?php echo e(Auth::User()->name); ?>, LOGOUT
                                    </a> 
                                    <form id="logout-form" action="<?php echo e(route('logout')); ?>" method="POST" style="display: none;">
                                        <?php echo csrf_field(); ?>
                                    </form>
   <?php else: ?>
    <a href="http://127.0.0.1:8000/login"  id="login-button" class="w3-bar-item w3-button w3-mobile log-button">Login</a>

   <?php endif; ?>
    </div>

</div>

<!-- -------------------- -->
<div  class="dropdown">
    <button onclick="myFunction()" class="dropbtn">VISUALIZZA</button>
    <div id="myDropdown" class="dropdown-content">
    
    <a href="http://127.0.0.1:8000/classroom">Aule</a>
    <a href="http://127.0.0.1:8000/office">Uffici</a>
    <a href="http://127.0.0.1:8000/secretariat">Segreterie</a>
    <a href="http://127.0.0.1:8000/food_drink">Cibi e bevande</a>
    <a href="http://127.0.0.1:8000/info_point">Info Point</a>
    <a href="http://127.0.0.1:8000/bus_stop">Fermate autobus</a>
    <a href="http://127.0.0.1:8000/library">Biblioteche</a>

    </div>
</div>
<!-- -------------------- -->
    <div class="root">
    <?php if(isset($type)): ?>
<h100> <a href="http://127.0.0.1:8000/"><b>Home</b></a><img  height="15px" src="/images/freccia.png" > <?php echo e($type); ?></h100>
<?php else: ?>


<?php if(isset($searchtxt)): ?>
<h100> Risultati della ricerca per : "<?php echo e($searchtxt); ?>"</h100>
<?php else: ?>
<h100> <b>Home</b></h100>
<?php endif; ?>
<?php endif; ?>

   </div>    
        <br>
        
    <div id="box">
 
<table>
<?php if(Auth::check()): ?>

    <?php if(isset($token)): ?>
    <?php if($token): ?>
    <form  action="http://127.0.0.1:8000/" >
    <input checked="checked" onclick="submit();" type="checkbox" id="vehicle1" name="cdl_id" value="<?php echo e(Auth::User()->cdl_id); ?>">
    <?php endif; ?>
    <?php else: ?>
    <form  action="http://127.0.0.1:8000/filter" method="GET">
    <input  onclick="submit();" type="checkbox" id="vehicle1" name="cdl_id" value="<?php echo e(Auth::User()->cdl_id); ?>">
    
    <?php endif; ?>

<label for="vehicle1"> Prioritizza POI</label><br>
</form>
<?php endif; ?>
<?php if(isset($poi)): ?>

<?php if(!empty($poi)): ?>
<?php $__currentLoopData = $poi; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $poi_data): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>


<tr class="table_box" >
<td class="table_icon"><img src="images/<?php echo e($poi_data['image']); ?> "></td>
<td class="table_name"> <?php echo e($poi_data['name_p']); ?> </td>
<td class="table_description"> <div style="overflow:scroll;"><?php echo e($poi_data['description']); ?> </div>

</td>
<td class="table_info"><a href="prova.php"><img src="/images/freccia.png"></a> </td>
</tr>



<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?> 
<?php endif; ?>

<?php endif; ?>
</table>
</div>



    <div id="mappa">
        <iframe src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d3041.2335208100008!2d13.34849825968263!3d42.36731783314539!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x132fcd66882dc14f%3A0xbfcd671e4e655ba9!2sUNIVAQ!5e0!3m2!1sit!2sit!4v1581370654551!5m2!1sit!2sit" width="800" height="600" frameborder="0" style="border:0;" allowfullscreen=""></iframe>
    </div>

       



<script>
/* When the user clicks on the button,
toggle between hiding and showing the dropdown content */
function myFunction() {
  document.getElementById("myDropdown").classList.toggle("show");
}
</script>

   

</body>
</html>

<?php /**PATH /Applications/MAMP_2019-12-19_15-33-51/htdocs/prog_team2/resources/views//welcome.blade.php ENDPATH**/ ?>