<!DOCTYPE html>

<html lang="<?php echo e(str_replace('_', '-', app()->getLocale())); ?>">
    <head>
   

        <title>PORTAMI A DESTINAZIONE</title>
        <link rel="stylesheet" href="css/style.css">
        <link rel="stylesheet" href="css/form-login.css">
        <link rel="stylesheet" href="https://www.w3schools.com/w3css/4/w3.css">
        <!-- Styles -->
       <style>
        </style>
    
</head>
    
<body>

    <div id="header">
        <div id="logo">
          <img  src="images/prova.png">
        </div>
        <div id="title">
        <h1>Portami a destinazione</h1> 
        </div>

    </div>
   



  
 
<div  class="w3-container">
     
  
  <div class="w3-bar w3-light-grey w3-border w3-padding">
    <a href="http://127.0.0.1:8000/" class="w3-bar-item w3-button w3-mobile">Torna alla mappa</a>
    
   <!-- <a href="#" class="w3-bar-item w3-button w3-mobile">Link 2</a> -->
   <?php if(Auth::check()): ?>
    
    
    <a class="w3-bar-item w3-button w3-mobile log-button" style="margin-left:80%;" href="<?php echo e(route('logout')); ?>"
                                       onclick="event.preventDefault();
                                                     document.getElementById('logout-form').submit();">
                                        Ciao <?php echo e(Auth::User()->name); ?>, LOGOUT
                                    </a> 
                                    <form id="logout-form" action="<?php echo e(route('logout')); ?>" method="POST" style="display: none;">
                                        <?php echo csrf_field(); ?>
                                    </form>
   <?php else: ?>
    <a href="http://127.0.0.1:8000/login"  id="login-button" class="w3-bar-item w3-button w3-mobile log-button">Login</a>

   <?php endif; ?>
    
    </div>

</div>


<!-- --------------- -->

        <!-- ------------->
        <br>
        
        <div id="dati">
        <?php $__currentLoopData = $student; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $st): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

    
    
    
   


<table class="dati">
                    <tr>
                        <td style="padding-bottom:30px;"><h10>nome:</h10></td ><td id="nome_area" style="padding-bottom:30px;"><h21> <?php echo e($st['name']); ?></h21></td>
                    </tr>
                    <tr>
                        <td style="padding-bottom:30px;"><h10>cognome:</h10></td><td id="cognome_area" style="padding-bottom:30px;"><h21><?php echo e($st['surname_s']); ?></h21></td>
                    <tr>
                        <td style="padding-bottom:30px; width:200px;"><h10>e-mail:</h10></td><td id="email_area" style="padding-bottom:30px;"><h22><?php echo e($st['email']); ?></h22></td>
                    </tr>
<tr>
                        <td><h10>matricola:</h10></td><td id="numero_area"><h21><?php echo e($st['freshman']); ?></h21></td>
                    </tr>
<tr>
                        <td><h10>Corso di laurea':</h10></td><td id="citta_area"><h21><?php echo e($st['description_c']); ?></h21></td>
                    </tr>
<tr>
                        <td><h10>dipartimento:</h10></td><td id="indirizzo_area"><h21> <?php echo e($st['name_d']); ?></h21></td>
                    </tr>
                    <tr>
                        <td><h10>password:</h10></td><td><h21>****************</h21></td><td><input class="tasto_modifica"value="Modifica"  type="button" name="isbn" onclick="location.href='#'"></td>
                    </tr>
                    
                
                    
                </table>
 </div>


    
 <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>





   

</body>
</html>

<?php /**PATH /Applications/MAMP_2019-12-19_15-33-51/htdocs/prog_team2/resources/views/info.blade.php ENDPATH**/ ?>