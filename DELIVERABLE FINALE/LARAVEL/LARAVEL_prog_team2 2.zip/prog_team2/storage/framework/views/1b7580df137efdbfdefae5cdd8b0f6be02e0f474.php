<!DOCTYPE html>

<html lang="<?php echo e(str_replace('_', '-', app()->getLocale())); ?>">
    <head>
   

        <title>PORTAMI A DESTINAZIONE</title>
        <link rel="stylesheet" href="css/style.css">
        <link rel="stylesheet" href="https://www.w3schools.com/w3css/4/w3.css">
        <!-- Styles -->
       <style>
/* Dropdown Button */
.dropbtn {
  background-color: #8B2525;
  color: white;
  padding: 16px;
  font-size: 16px;
  border: none;
  cursor: pointer;
}

/* Dropdown button on hover & focus */
.dropbtn:hover, .dropbtn:focus {
  background-color: #d53131;
}

/* The search field */
#myInput {
  box-sizing: border-box;
  background-image: url('searchicon.png');
  background-position: 14px 12px;
  background-repeat: no-repeat;
  font-size: 16px;
  padding: 14px 20px 12px 45px;
  border: none;
  border-bottom: 1px solid #ddd;
}

/* The search field when it gets focus/clicked on */
#myInput:focus {outline: 3px solid #ddd;}

/* The container <div> - needed to position the dropdown content */
.dropdown {
  position: relative;
 margin-left:475px;
  display: inline-block;
  margin-bottom: 10px;
  margin-top: 20px;
}

/* Dropdown Content (Hidden by Default) */
.dropdown-content {
  display: none;
  position: absolute;
  background-color: #f6f6f6;
  min-width: 230px;
  border: 1px solid #ddd;
  z-index: 1;
}

/* Links inside the dropdown */
.dropdown-content a {
  color: black;
  padding: 12px 16px;
  text-decoration: none;
  display: block;
}

/* Change color of dropdown links on hover */
.dropdown-content a:hover {background-color: #f1f1f1}

/* Show the dropdown menu (use JS to add this class to the .dropdown-content container when the user clicks on the dropdown button) */
.show {display:block;}
        </style>
    
</head>
    
<body>

    <div id="header">
        <div id="logo">
          <img  src="images/prova.png">
        </div>
        <div id="title">
        <h1>PORTAMI A DESTINAZIONE</h1> 
        </div>

    </div>
  
 
<div  class="w3-container">
     
  
  <div class="w3-bar w3-light-grey w3-border w3-padding">
    <a href="http://127.0.0.1:8000/" class="w3-bar-item w3-button w3-mobile">Home</a>
    <a href="http://127.0.0.1:8000/login" class="w3-bar-item w3-button w3-mobile log-button">Login</a>
   <!-- <a href="#" class="w3-bar-item w3-button w3-mobile">Link 2</a> -->
    <input type="text" class="w3-bar-item w3-input w3-white w3-mobile" placeholder="Search..">
    <button class="w3-bar-item w3-button w3-mobile search_button">Go</button>
    
    </div>

</div>

<!-- -------------------- -->
<div  class="dropdown">
    <button onclick="myFunction()" class="dropbtn">VISUALIZZA</button>
    <div id="myDropdown" class="dropdown-content">
    
    <a href="http://127.0.0.1:8000/classroom">Aule</a>
    <a href="#base">Uffici</a>
    <a href="#blog">Segreterie</a>
    <a href="#contact">Cibi e bevande</a>
    <a href="#custom">Info Point</a>
    <a href="#support">Fermate autobus</a>
    <a href="#tools">Biblioteche</a>

    </div>
</div>
<!-- -------------------- -->
        
        <br>
        
    <div id="box">
        <!--
<table>
<tr class="table_box" >
    <td class="table_icon"><img src="images/info-point.png"></td>
    <td class="table_name"> A 1.1 </td>
    <td class="table_description">

    </td>
    <td class="table_info">Colonna 1</td>
</tr>
</table>
<hr style="width:40px; margin-top:5px;">
<table>
<tr class="table_box" >
    <td class="table_icon"><img src="images/info-point.png"></td>
    <td class="table_name"> A 1.1 </td>
    <td class="table_description">Aula A 0.3, PIANO TERRA, EDIFICIO: COPPITO 0 </td>
    <td class="table_info">Colonna 1</td>
</tr>
</table>
<hr style="width:40px; margin-top:5px;">
<table>
<tr class="table_box" >
    <td class="table_icon"><img src="images/info-point.png"></td>
    <td class="table_name"> A 1.1 </td>
    <td class="table_description">Aula A 0.3, PIANO TERRA, EDIFICIO: COPPITO 0 </td>
    <td class="table_info">Colonna 1</td>
</tr>
</table>
<hr style="width:40px; margin-top:5px;">


-->

<?php if(isset($poi)): ?>

<?php if(!empty($poi)): ?>
<?php $__currentLoopData = $poi; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $poi_data): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

<table>
<tr class="table_box" >
<td class="table_icon"><img src="images/<?php echo e($poi_data['image']); ?> "></td>
<td class="table_name"> <?php echo e($poi_data['name_p']); ?> </td>
<td class="table_description"> <?php echo e($poi_data['description']); ?> 

</td>
<td class="table_info">Colonna 1</td>
</tr>
</table>
<hr style="width:40px; margin-top:5px;">

<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?> 

<?php endif; ?>


<?php endif; ?>
</div>



    <div id="mappa">
        <iframe src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d3041.2335208100008!2d13.34849825968263!3d42.36731783314539!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x132fcd66882dc14f%3A0xbfcd671e4e655ba9!2sUNIVAQ!5e0!3m2!1sit!2sit!4v1581370654551!5m2!1sit!2sit" width="800" height="600" frameborder="0" style="border:0;" allowfullscreen=""></iframe>
    </div>

       



<script>
/* When the user clicks on the button,
toggle between hiding and showing the dropdown content */
function myFunction() {
  document.getElementById("myDropdown").classList.toggle("show");
}
</script>

   

</body>
</html>

<?php /**PATH /Applications/MAMP_2019-12-19_15-33-51/htdocs/prog_team2/resources/views/welcome.blade.php ENDPATH**/ ?>