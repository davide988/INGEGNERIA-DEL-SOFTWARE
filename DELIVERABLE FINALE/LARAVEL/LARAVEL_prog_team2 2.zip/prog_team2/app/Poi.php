<?php

namespace App;

use Illuminate\Database\Eloquent\Model;


class Poi extends Model
{
     protected $table = 'poi';
    public $timestamps=false;
    protected $primaryKey='id_p';
    
    public function Admin()
    {
        return $this->belongsTo('App\Admin'); 
    }
    
    public function Cdl()
    {
        return $this->belongsToMany('App\Cdl', 'poi_cdl', 'poi_id', 'cdl_id'); 
    }
    
    
}
