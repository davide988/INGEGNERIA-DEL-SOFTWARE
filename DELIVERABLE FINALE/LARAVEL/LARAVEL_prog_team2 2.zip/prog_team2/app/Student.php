<?php

namespace App;

use Illuminate\Database\Eloquent\Model;
use Illuminate\Foundation\Auth\User as Authenticatable;

class Student extends Authenticatable
{
     protected $table = 'students';
    
    protected $primaryKey='freshman';
    
    public function Cdl()
    {
        return $this->belongsTo('App\Cdl'); 
}
}