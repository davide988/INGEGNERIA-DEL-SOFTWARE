<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class Professor extends Model
{
    protected $table = 'professors';
    protected $primaryKey='email_p';

      public function Cdl()
    {
        return $this->belongsToMany('App\Cdl', 'professors_cdl', 'professors_id','cdl_id' ); 
    
    }
}
