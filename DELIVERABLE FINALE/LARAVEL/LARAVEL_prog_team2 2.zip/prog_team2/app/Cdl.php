<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class Cdl extends Model
{
      protected $table = 'cdl';
    
    protected $primaryKey='id_c';
    
  
    public function Poi()
    {
        return $this->belongsToMany('App\Poi', 'poi_cdl', 'cdl_id', 'poi_id'); 
    }

    public function Student()
    {
        return $this->hasMany('App\Student'); 
    }
   public function Department()
    {
        return $this->belongsTo('App\Department'); 
    }
    public function Professor()
    {
        return $this->belongsToMany('App\Professor', 'professors_cdl', 'cdl_id', 'professors_id'); 
    }
}
