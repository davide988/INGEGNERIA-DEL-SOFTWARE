<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class Admin extends Model
    
{
    protected $table = 'admins';
    
    protected $primaryKey='username';
    
    public function poi()
    {
        return $this->hasMany('App\poi'); 
    }
}
