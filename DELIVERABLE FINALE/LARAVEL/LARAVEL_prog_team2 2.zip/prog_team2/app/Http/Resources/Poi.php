<?php

namespace App\Http\Resources;

use Illuminate\Http\Resources\Json\JsonResource;

class Poi extends JsonResource
{
    /**
     * Transform the resource into an array.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return array
     */
    public function toArray($request)
    {
        return [
            'name_p' => $this->name_p,
            'type' => $this->type,
            'description' => $this->description,
            'image'=>$this->image,
            'area_p' => $this->area_p,
            'address' => $this->address,
            'position' => $this->position,
           
        ];
    }
}
