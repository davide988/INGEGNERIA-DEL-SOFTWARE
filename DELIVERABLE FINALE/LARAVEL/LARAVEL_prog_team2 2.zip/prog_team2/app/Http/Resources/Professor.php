<?php

namespace App\Http\Resources;

use Illuminate\Http\Resources\Json\JsonResource;

class Professor extends JsonResource
{
    /**
     * Transform the resource into an array.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return array
     */
    public function toArray($request)
    {
        return [
            'name_p' => $this->name_p,
            'surname_p' => $this->surname_p,
            'email_p' => $this->email_p
            
            
        ];
    }
}
