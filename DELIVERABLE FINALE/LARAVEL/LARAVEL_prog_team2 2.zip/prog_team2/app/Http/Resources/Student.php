<?php

namespace App\Http\Resources;

use Illuminate\Http\Resources\Json\JsonResource;

class Student extends JsonResource
{
    /**
     * Transform the resource into an array.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return array
     */
    public function toArray($request)
    {
        return [
            'freshman' => $this->freshman,
            'email_s' => $this->email_s,
            'name_s' => $this->name_s,
            'surname_s' => $this->surname_s,
            'cdl_id' => $this->cdl_id
            
           
        ];
    }
}
