<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Department;
use App\Http\Resources\Department as DepartmentResources;
class DepartmentController extends Controller
{
   
    public function index()
    {
        return response (DepartmentResources::collection(Department::all()), 200)
          ->header('Content-Type', 'application/json');
    }

   
    public function create()
    {
        //
    }

    
    public function store(Request $request)
    {
        $department= new Department;
        $department-> id_d = $request->id_d;
        $department-> name_d = $request->name_d;
        
        
        

        if ($department->save()) return response (null, 200);
        else abort(500);
    }

    
    public function show($id_d)
    {
        return response (new DepartmentResources(Department::findOrFail($id_d)),200)
          ->header('Content-Type', 'application/json');

    }

    
    
    public function update(Request $request, $id_d)
    {
        $department = Department::findOrFail($id_d);
        if(!$department) {
            return response()->json(["Errore", 'code' => 404], 404);
        }

            $department->name_d= $request->name_d;
    
        
        if ($department->save()) return response (null, 200);
        else abort(500);

    }

    
    public function destroy($id_d)
    {
        Department::findOrFail($id_d);

        if (Department::destroy($id_d)) return response (null, 200);
        else abort (500);
    }
}