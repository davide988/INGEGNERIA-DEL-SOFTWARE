<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Student;
use App\Cdl;
use App\Department;
use Illuminate\Support\Facades\Hash;
use App\Http\Resources\Student as StudentResources;

class StudentController extends Controller
{
    
    public function index()
    {
        return response (StudentResources::collection(Student::all()), 200)
          ->header('Content-Type', 'application/json');
    }

    
    public function create()
    {
        //
    }

    
    public function store(Request $request)
    {
      
        $student= new Student;
        $student-> freshman = $request->freshman;
        $student-> email = $request->email;

        $password=$request->password;
        $student-> password =Hash::make($password);

        


        $student-> name = $request->name;
        $student-> surname_s = $request->surname_s;
        
        
        $cdl= $request->cdl_id;
        //$poi-> created_at = $request->;
        //$poi-> updated_at = $request->;
        
        $search = Cdl::findorFail($cdl);
        if ($search == null) abort(404);
        $student-> cdl_id = $request->cdl_id;

        if ($student->save()) return response (null, 200);
        else abort(500);
    }

    
    public function show(Request $freshman)
    {
     $current_freshman=$freshman->freshman;   
    

    $student=Student::join('cdl', 'cdl_id', '=', 'cdl.id_c')->join('departments', 'department_id','=','departments.id_d')
    ->where('freshman', '=', $current_freshman )->get();
    
    
   
    
    return 

     view ('info',
                [
                    'student'=>$student
                ]
                );
     


      
    /*
        return response (new StudentResources(Student::findOrFail($freshman)->get()),200)
          ->header('Content-Type', 'application/json'); */
    }
    public function showcdl($freshman)
    {
       $cdl=Student::findOrFail($freshman);
         $course_code=$cdl->cdl_id;
        return $course_code;
        }

   
    public function edit($id)
    {
        //
    }

    
    public function update(Request $request, $id)
    {
        $student = Student::findOrFail($freshman);
        if(!$student) {
            return response()->json(["Errore", 'code' => 404], 404);
        }


        if ($request->has('email')) {
            $student->email_s = $request->email_s;
        };
        if ($request->has('password')) {
            $student->password_s = $request->password_s;
        };
        if ($request->has('name')) {
            $student->name_s = $request->name_s;
        };
        if ($request->has('surname_s')) {
            $student->surname_s = $request->surname_s;
        };

        if ($student->save()) return response (null, 200);
        else abort(500);

    }

    
    public function destroy($freshman)
    {
        Student::findOrFail($freshman);

        if (Student::destroy($freshman)) return response (null, 200);
        else abort (500);
    }
}