<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Cdl;
use App\Department;
use App\Http\Resources\Cdl as CdlResources;
class CDLcontroller extends Controller
{
   
    public function index()
    {
        return response (CdlResources::collection(Cdl::all()), 200)
        ->header('Content-Type', 'application/json');
    }

   
    public function store(Request $request)
    {
        $cdl= new Cdl;
        $cdl-> id_c = $request->id_c;
        $cdl-> description_c = $request->description_c;
        $cdl-> name_c = $request->name_c;
        $cdl-> area_c = $request->area_c;
        
        
        $department= $request->department_id;
        
        
        $search = Department::find($department);
        if ($search == null) abort(404);
        $cdl-> department_id = $request->department_id;

        if ($cdl->save()) return response (null, 200);
        else abort(500);
        
    }

    
    public function show($id_c)
    {
        // $Cdl = cdl:: find($code_c);
        // return $Cdl;
        return response (new CdlResources(Cdl::findOrFail($id_c)),200)
          ->header('Content-Type', 'application/json');
    }

    
     
    
    public function update(Request $request, $id_c)
    {
        $cdl = Cdl::findOrFail($id_c);
        if(!$cdl) {
            return response()->json(["Errore", 'code' => 404], 404);
        }


        if ($request->has('name_c')) {
            $cdl->name_c = $request->name_c;
        };
        if ($request->has('description_c')) {
            $cdl->description_c = $request->description_c;
        };
         if ($request->has('area_c')) {
            $cdl->area_c = $request->area_c;
         };
        

    

        if ($cdl->save()) return response (null, 200);
        else abort(500);
    }

    
    public function destroy($id_c)
    {
        Cdl::findOrFail($id_c);

        if (Cdl::destroy($id_c)) return response (null, 200);
        else abort (500);
    }
}