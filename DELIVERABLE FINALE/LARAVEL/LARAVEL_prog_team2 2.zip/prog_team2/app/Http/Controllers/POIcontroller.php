<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Poi;
use App\Cdl;
use App\Admin;
use App\Http\Resources\Poi as PoiResources;
use App\Http\Resources\Cdl as CdlResources;

class POIcontroller extends Controller
{
     
//INDEX(LISTA DI TUTTI I POI)

    public function index()
    {
      $poi=PoiResources::collection(Poi::all());
        
        return view ('/welcome',
        [
            'poi'=>$poi
        ]
        );
    }
    public function indexclassroom()
    {
        $poi=PoiResources::collection(Poi::where('type', '=', 'aula')->get());
 
        return view ('/welcome',
        [
            'poi'=>$poi,
            'type'=>"Aule"
        ]
        );
    }

    public function indexfood_drink()
    {
        $poi=PoiResources::collection(Poi::where('type', '=', 'cibi e bevande')->get());
        return view ('/welcome',
        [
            'poi'=>$poi,
            'type'=>"Mense, Bar, Distr.auto."
        ]
        );
    }

    public function indexoffice()
    {
        $poi= PoiResources::collection(Poi::where('type', '=', 'ufficio')->get());

            return view ('/welcome',
            [
                'poi'=>$poi,
                'type'=>"Uffici"
            ]
            );
    }
    public function indexsecretariat()
    {
       $poi= PoiResources::collection(Poi::where('type', '=', 'segreteria studenti')->get());

            return view ('/welcome',
            [
                'poi'=>$poi,
                'type'=>"Segreterie"
            ]
            );
    }

    public function indexbus_stop()
    {
        $poi= PoiResources::collection(Poi::where('type', '=', 'fermata bus')->get());

            return view ('/welcome',
            [
                'poi'=>$poi,
                'type'=>"Fermate autobus"
            ]
            );
    }

    public function indexinfo_point()
    {
    $poi=PoiResources::collection(Poi::where('type', '=', 'info point')->get());
            return view ('/welcome',
            [
                'poi'=>$poi,
                'type'=>"Info point"
            ]
            );
    }
    public function indexlibrary()
    {
       $poi=PoiResources::collection(Poi::where('type', '=', 'biblioteca')->get());

            return view ('/welcome',
            [
                'poi'=>$poi,
                'type'=>"Biblioteche"
            ]
            );
    }
    public function indextoilet()
    {
        return response (PoiResources::collection(Poi::where('type', '=', 'servizi igienici')->get()), 200)
            ->header('Content-Type', 'application/json');
    }



    
    public function store(Request $request)
    {
        $poi= new Poi;
        $poi-> id_p = $request->id_p;
        $poi-> name_p = $request->name_p;
        $poi-> type = $request->type;
        $poi-> description = $request->description;
        $poi-> image = $request->image;
        $poi-> area_p = $request->area_p;
        $poi-> address = $request->address;
        $poi-> position = $request->position;
        
        $admin= $request->admin_id;
        //$poi-> created_at = $request->;
        //$poi-> updated_at = $request->;
        
        $search = Admin::find($admin);
        if ($search == null) abort(404);
        $poi-> admin_id = $request->admin_id;

        if ($poi->save()) return response (null, 200);
        else abort(500);
        
    }
// SHOW -> DATO IL CODICE DI UN POI RESTITUISCE LE INFORMAZIONI DI QUEL POI
    public function show($id_p)
    {
        return response (new PoiResources(Poi::findOrFail($id_p)),200)
          ->header('Content-Type', 'application/json');

    }

  // SHOWPOI -> DATO IL CODICE DI UN CORSO DI LAUREA RESTITUISCE I POI ASSOCIATI A QUEL CORSO   
   
    public function showpoi(Request $cdl_id)
    {
        $id_c=$cdl_id->cdl_id;
    $poi=Cdl::findOrFail($id_c)->Poi;
   
    return view ('/welcome',
    [
        'poi'=>$poi,
        'type'=>"P.O.I. suggeriti",
        'token'=>"1"
    ]
    );
    
        //return response (new PoiResources(Cdl::findOrFail($id_c)->Poi),200)
        //    ->header('Content-Type', 'application/json');

    }

    
    public function showsearch( Request $searchText){
        $search=$searchText->searchText;

    $query=Poi::where('name_p', 'LIKE','%' . $search . '%' )
    ->orWhere('type', 'LIKE','%' . $search . '%' )->get();
    
    $poi= PoiResources::collection($query);
      
                return 
                view ('/welcome',
                [
                    'poi'=>$poi,
                    'searchtxt'=>$search
                ]
                );
     


    }

    
    

    

    
    //UPDATE 
     public function update(Request $request, $id_p)
    {
        
        $poi = Poi::findOrFail($id_p);
        if(!$poi) {
            return response()->json(["Errore", 'code' => 404], 404);
        }


        if ($request->has('name_p')) {
            $poi->name_p = $request->name_p;
        };
        if ($request->has('description')) {
            $poi->description = $request->description;
        };
        if ($request->has('area_p')) {
            $poi->area_p = $request->area_p;
        };
        if ($request->has('image')) {
            $poi->image = $request->image;
        };

        if ($poi->save()) return response (null, 200);
        else abort(500);





    }

   
    public function destroy($id_p)
    {
        Poi::findOrFail($id_p);

        if (Poi::destroy($id_p)) return response (null, 200);
        else abort (500);
    }
}
