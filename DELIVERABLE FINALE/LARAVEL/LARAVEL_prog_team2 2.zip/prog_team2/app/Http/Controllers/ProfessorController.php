<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Professor;
use App\Http\Resources\Professor as ProfessorResources;
use Illuminate\Support\Facades\Hash;
class ProfessorController extends Controller
{
    
    public function index()
    {
        return response (ProfessorResources::collection(Professor::all()), 200)
          ->header('Content-Type', 'application/json');
    }

    
   

    
    public function store(Request $request)
    {
        $professor= new Professor;
        
        $professor-> email_p = $request->email_p;
        
        $password=$request->passwprd_p;
        $professor-> password_p=Hash::make($password);
        
        $professor-> name_p = $request->name_p;
        $professor-> surname_p = $request->surname_p;
        
        
        

        if ($professor->save()) return response (null, 200);
        else abort(500);
    }

    
    public function show($email_p)
    {
        return response (new ProfessorResources(Professor::findOrFail($email_p)),200)
          ->header('Content-Type', 'application/json');
    }

    
    public function edit($id)
    {
        //
    }

    
    public function update(Request $request, $email_p)
    {
        $professor = Professor::findOrFail($email_p);
        if(!$professor) {
            return response()->json(["Errore", 'code' => 404], 404);
        }


        if ($request->has('name_p')) {
            $professor->name_p = $request->name_p;
        };
        if ($request->has('password_p')) {
            $professor->password_p = $request->password_p;
        };
        if ($request->has('name_p')) {
            $professor->name_p = $request->name_p;
        };
        if ($request->has('surname_p')) {
            $professor->surname_p = $request->surname-p;
        };

        if ($professor->save()) return response (null, 200);
        else abort(500);
    }

   
    public function destroy($email_p)
    {
        Professor::findOrFail($email_p);

        if (Professor::destroy($email_p)) return response (null, 200);
        else abort (500);
    }
}