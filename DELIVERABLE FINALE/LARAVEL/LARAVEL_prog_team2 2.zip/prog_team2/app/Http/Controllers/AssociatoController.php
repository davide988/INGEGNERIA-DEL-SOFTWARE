<?php

namespace App\Http\Controllers;
use App\Poi;
use App\Cdl;
use Illuminate\Http\Request;

class AssociatoController extends Controller
{
    
    public function index()
    {
        $poi_cdl= Poi::all();
    }

    
    public function store(Request $request)
    {
        $associate= new poi_cdl();
        $associate-> poi_id = $request->poi_id;
        $associate-> cdl_id = $request->cdl_id;
        $associate->save();
    }

    
   

    
}
