<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

class CreateTablePresiede extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        Schema::create('presiede', function (Blueprint $table) {
            $table->string('Codice_C');
            $table->string('Email_D');
            
            $table->foreign('Codice_C')->references('Codice_C')->on('CDL');
            $table->foreign('Email_D')->references('Email_D')->on('docente');
            
        });
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        Schema::dropIfExists('presiede');
    }
}
