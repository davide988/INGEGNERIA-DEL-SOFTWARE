<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

class CreateTableAssociato extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        Schema::create('associato', function (Blueprint $table) {
            $table->string('Codice_P');
            $table->string('Codice_C');
            
            $table->foreign('Codice_P')->references('Codice_P')->on('POI');
            $table->foreign('Codice_C')->references('Codice_C')->on('CDL');
        });
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        Schema::dropIfExists('associato');
    }
}
