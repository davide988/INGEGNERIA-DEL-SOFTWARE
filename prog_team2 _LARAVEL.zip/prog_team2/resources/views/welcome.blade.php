<!DOCTYPE html>
<html lang="{{ str_replace('_', '-', app()->getLocale()) }}">
    <head>
        

        <title>PORTAMI A DESTINAZIONE</title>

        
        <!-- Styles -->
        <style>
           
        </style>
    </head>
    <body>
        
    </body>
</html>
