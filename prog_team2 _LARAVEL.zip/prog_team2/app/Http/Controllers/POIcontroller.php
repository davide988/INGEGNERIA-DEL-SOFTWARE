<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\POI;
class POIcontroller extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
        $POI= POI::all();
        return $POI;
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        //
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {
        $poi= new POI();
        $poi-> Codice_P = $request->Codice_P;
        $poi-> Nome_P = $request->Nome_P;
        $poi-> Tipologia = $request->Tipologia;
        $poi-> Descrizione = $request->Descrizione;
        $poi-> coordinate = $request->coordinate;
        $poi-> Username = $request->Username;

        $poi->save();
    }

    /**
     * Display the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function show($Codice_P)
    {
        $poi = POI:: find($Codice_P);
        return $poi;
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function edit($id)
    {
        //
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, $Codice_P)
    {
        $poi = POI:: find ($Codice_P);
        $utente-> Descrizione = $request->Descrizione;
        
        $utente-> save();

    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function destroy($Codice_P)
    {
         $poi = POI ::find($Codice_P);
        $poi-> delete();
    }
}
