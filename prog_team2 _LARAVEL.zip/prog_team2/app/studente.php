<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class studente extends Model
{
     protected $table = 'studente';
    
    protected $primaryKey='matricola';
    
    public function CDL()
    {
        return $this->belongsTo('App\CDL'); 
}
