<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class POI extends Model
{
     protected $table = 'POI';
    
    protected $primaryKey='Codice_P';
    
    public function amministartore()
    {
        return $this->belongsTo('App\amministartore'); 
    }
    
    public function CDL()
    {
        return $this->belongsToMany('App\CDL', 'associato'); 
    }
    
    
}
