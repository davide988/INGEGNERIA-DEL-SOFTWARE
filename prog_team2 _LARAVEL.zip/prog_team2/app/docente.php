<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class docente extends Model
{
public function CDL()
    {
        return $this->belongsToMany('App\CDL', 'presiede'); 
    }
}
