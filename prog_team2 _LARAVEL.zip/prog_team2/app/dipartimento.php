<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class dipartimento extends Model
{
    public function CDL()
    {
        return $this->hasMany('App\CDL'); 
    }
}
