<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class amministratore extends Model
    
{
    protected $table = 'amministratore';
    
    protected $primaryKey='Username';
    
    public function poi()
    {
        return $this->hasMany('App\POI'); 
    }
}
