<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class CDL extends Model
{
      protected $table = 'CDL';
    
    protected $primaryKey='Codice_C';
    
  
    public function POI()
    {
        return $this->belongsToMany('App\POI', 'associato'); 
    }

    public function studente()
    {
        return $this->hasMany('App\studente'); 
    }
   public function dipartimento()
    {
        return $this->belongsTo('App\dipartimento'); 
    }
    public function docente()
    {
        return $this->belongsToMany('App\docente', 'presiede'); 
    }
}
